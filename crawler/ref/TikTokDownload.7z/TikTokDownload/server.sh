cd Util
cd algorithm
python3 Server.py