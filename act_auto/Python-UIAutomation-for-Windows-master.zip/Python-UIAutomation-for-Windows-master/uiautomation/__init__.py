from __future__ import absolute_import

from .version import VERSION
from .uiautomation import *
